<footer class="footer">
<div class="container">
<span class="text-muted">Projet PHP 7/12/18 - Lacaze Thomas, Noé Bellefon, Steven Kerautret, Aurélien Brunet, Jibril Zioui, Benjamin Gogo</span>
<img src="https://projet.thomaslacaze.fr/assets/img/logo_uvsq.png" class="rounded float-right" style="width:110px;height:55px;" />
</div>
</footer>
<script src="https://ajax.cloudflare.com/cdn-cgi/scripts/2448a7bd/cloudflare-static/rocket-loader.min.js" data-cf-nonce="dcf745ca14fba0904d5e53a9-" defer=""></script></body>
</html>